import React, { useState } from 'react';
import BuscarModelo from './components/BuscarModelo';
import ListaProductos from './components/ListaProductos';
import Presupuesto from './components/Presupuesto';

console.log("🚀 App.jsx se está cargando...");

function App() {
  const [productos, setProductos] = useState([]);

  return (
    <div className="container mt-5">
      <h1 className="text-center">Presupuesto de Cambio de Aceite</h1>
      <BuscarModelo setProductos={setProductos} />
      <ListaProductos productos={productos} setProductos={setProductos} />
      <Presupuesto productos={productos} />
    </div>
  );
}

export default App;